# Virtus Math Bot

A starter Android app for reading screenshots of **practice** maths questions with on-device text recognition (Google ML Kit), then sharing the recognised question with an AI tutor for a step-by-step explanation.

## Build the APK from GitHub
1. Add these files to the root of your `Virtus-Math-Bot` repository, keeping the folder structure.
2. Commit the files to the `main` branch.
3. Open the repository's **Actions** tab.
4. Select **Build Android APK** and wait for the workflow to finish.
5. Open the completed run and download the `Virtus-Math-Bot-APK` artifact. Extract it to find `app-debug.apk`.

## Use
- Take a screenshot of a practice question in Chrome.
- Share the screenshot to Virtus Math Bot, or open the app and choose the screenshot.
- Check the recognised text.
- Tap **Send question to AI tutor** and choose an AI app.

## Important
- This starter app does not automatically tap or submit answers.
- Review OCR text before sharing; screenshots may contain personal information.
- The AI tutor app/service you choose may have its own account, privacy, and usage requirements.
- This starter project has not been tested on your specific phone yet.
