package za.co.virtusmathbot

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

class MainActivity : Activity() {
    private lateinit var result: TextView
    private var recognisedText: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 32, 24, 24)
        }
        val title = TextView(this).apply {
            text = "Virtus Math Bot"
            textSize = 26f
        }
        val intro = TextView(this).apply {
            text = "Share a screenshot of a practice question to this app. It will read the text and let you send the question to an AI tutor for an explanation."
            textSize = 16f
            setPadding(0, 18, 0, 18)
        }
        val choose = Button(this).apply {
            text = "Choose screenshot"
            setOnClickListener {
                val i = Intent(Intent.ACTION_GET_CONTENT).apply { type = "image/*" }
                startActivityForResult(i, 100)
            }
        }
        result = TextView(this).apply {
            text = "Recognised question will appear here."
            textSize = 16f
            setPadding(0, 20, 0, 20)
        }
        val send = Button(this).apply {
            text = "Send question to AI tutor"
            setOnClickListener { shareQuestion() }
        }
        val note = TextView(this).apply {
            text = "Review the recognised text before sharing. This app does not submit answers or tap options for you."
            textSize = 13f
            setPadding(0, 18, 0, 0)
        }
        layout.addView(title)
        layout.addView(intro)
        layout.addView(choose)
        val scroll = ScrollView(this)
        scroll.addView(result)
        layout.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        layout.addView(send)
        layout.addView(note)
        setContentView(layout)
        if (intent?.action == Intent.ACTION_SEND && intent.type?.startsWith("image/") == true) {
            @Suppress("DEPRECATION")
            val uri = if (Build.VERSION.SDK_INT >= 33)
                intent.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
            else intent.getParcelableExtra(Intent.EXTRA_STREAM)
            uri?.let { runOcr(it) }
        }
    }

    @Deprecated("Deprecated in Android 13, retained for compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 100 && resultCode == Activity.RESULT_OK) {
            data?.data?.let { runOcr(it) }
        }
    }

    private fun runOcr(uri: Uri) {
        try {
            val bitmap: Bitmap = if (Build.VERSION.SDK_INT >= 28) {
                val source = ImageDecoder.createSource(contentResolver, uri)
                ImageDecoder.decodeBitmap(source)
            } else {
                @Suppress("DEPRECATION")
                MediaStore.Images.Media.getBitmap(contentResolver, uri)
            }
            val image = InputImage.fromBitmap(bitmap, 0)
            val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
            result.text = "Reading screenshot…"
            recognizer.process(image)
                .addOnSuccessListener { visionText ->
                    recognisedText = visionText.text
                    result.text = if (recognisedText.isBlank()) "No readable text found. Try a clearer screenshot." else recognisedText
                }
                .addOnFailureListener { e ->
                    result.text = "Could not read this image: ${e.localizedMessage}"
                }
        } catch (e: Exception) {
            result.text = "Could not open image: ${e.localizedMessage}"
        }
    }

    private fun shareQuestion() {
        if (recognisedText.isBlank()) {
            result.text = "First choose a screenshot with a practice question."
            return
        }
        val share = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, "Please explain this maths practice question step by step, and show how to check the answer:\n\n$recognisedText")
        }
        startActivity(Intent.createChooser(share, "Choose your AI tutor"))
    }
}
